# SIH PS 26123 — Edge-AI Multi-AMR Fleet Dashboard

Dashboard updated for the proposed **Edge-AI Based Distributed Fleet Coordination for Autonomous Mobile Robots (AMRs) in Smart Warehouses** solution.

## Hardware / architecture shown in the dashboard
- Raspberry Pi 5 on each AMR as the edge compute node
- AprilTag camera for fiducial-based localization / pose updates
- Peer-to-peer robot telemetry and conflict negotiation
- No central cloud planner in the coordination loop

> The browser dashboard is a simulation/demo. It does not directly connect to a Raspberry Pi camera. The fiducial grid is rendered deterministically to represent the localization layer; a physical implementation would feed AprilTag detections into the pose interface.

## Algorithm stack
| No. | Algorithm | Dashboard role |
|---|---|---|
| A01 | Space-Time A* | Global path planning with time-aware reservations |
| A02 | Pose & Odometry (AprilTag) | Robot pose / movement state representation |
| A03 | Dynamic Obstacle Detection | Detect blocked/dynamic cells; simulation/vision overlay |
| A04 | P2P Telemetry Mesh | Robot-to-robot position and intent exchange |
| A05 | TTC Collision Prediction | Predict trajectory clashes before collision |
| A06 | Priority Arbitration | Resolve conflicts using cargo, urgency, battery and distance |
| A07 | Intersection Reservation | Prevent simultaneous entry into critical intersections |
| A08 | Wait-For Graph Recovery | Detect cyclic waiting and recover from deadlocks |
| A09 | Dynamic Replanning | Recompute a time-reserved route around hazards/conflicts |
| A10 | Auction Task Allocation | Assign pending missions to the lowest-cost eligible AMR |
| A11 | Battery/Stall Reassignment | Handoff tasks when battery is critical or robot stalls |
| A12 | Aisle Traffic Bias | Encourage directional flow and reduce opposing traffic |
| A13 | Benchmarking | Compare decentralized throughput against stop-and-wait baseline |

## SIH success criteria represented
- Zero inter-robot collisions: monitored through A05/A06/A07/A08/A09.
- Minimum 20% task-time/throughput improvement target: shown in the benchmark panel against the **stop-and-wait** baseline.

## Run
Open `index.html` in a modern browser. For local development, serving the folder through a simple HTTP server is recommended.
