/* ============================================================
 *  GRID — Warehouse topology, node classification, dynamic obstacles
 *  Supports 13-Algorithm Multi-AMR Architecture
 * ============================================================ */

class WarehouseGrid {
    constructor() {
        this.cols = CONFIG.GRID_COLS;
        this.rows = CONFIG.GRID_ROWS;
        
        // Dynamic runtime obstacles placed by user or simulated hazards: Map<string, { col, row, addedAt, duration }>
        this.dynamicObstacles = new Map();
        
        // Static shelf layout lookup
        this.shelfCells = new Set();
        this.shelfSlots = CONFIG.SHELF_SLOTS;
        this._initShelfCells();

        // Intersection cache for AprilTag placement & lock points
        this.intersections = new Set();
        this._initIntersections();
    }

    /* ---- Initialize Shelf Bounds ---- */
    _initShelfCells() {
        for (const c of CONFIG.SHELF_COLS) {
            for (let r = CONFIG.SHELF_ROW_START; r <= CONFIG.SHELF_ROW_END; r++) {
                this.shelfCells.add(`${c},${r}`);
            }
        }
    }

    /* ---- Identify Key Intersections ---- */
    _initIntersections() {
        for (let c = 0; c < this.cols; c++) {
            for (let r = 0; r < this.rows; r++) {
                if (this.isWalkable(c, r)) {
                    // Check number of valid orthagonal neighbors
                    const neighbors = this.getRawOrthogonalNeighbors(c, r);
                    if (neighbors.length >= 3) {
                        this.intersections.add(`${c},${r}`);
                    }
                }
            }
        }
    }

    /* ---- Boundary & Walkability Checks ---- */
    isValidCoord(col, row) {
        return col >= 0 && col < this.cols && row >= 0 && row < this.rows;
    }

    isShelf(col, row) {
        return this.shelfCells.has(`${col},${row}`);
    }

    hasDynamicObstacle(col, row) {
        return this.dynamicObstacles.has(`${col},${row}`);
    }

    isWalkable(col, row) {
        if (!this.isValidCoord(col, row)) return false;
        if (this.isShelf(col, row)) return false;
        if (this.hasDynamicObstacle(col, row)) return false;
        return true;
    }

    // Static walkability (ignoring transient dynamic obstacles)
    isStaticallyWalkable(col, row) {
        if (!this.isValidCoord(col, row)) return false;
        if (this.isShelf(col, row)) return false;
        return true;
    }

    /* ---- Zone Classification ---- */
    getZoneAt(col, row) {
        if (col === CONFIG.PICKUP_COL && row === CONFIG.BOTTOM_ROW) return 'PICKUP';
        if (col === CONFIG.DROPOFF_COL && row === CONFIG.BOTTOM_ROW) return 'DROPOFF';
        if (this.isShelf(col, row)) return 'SHELF';
        if (row === CONFIG.BOTTOM_ROW && CONFIG.BOT_START_COLS.includes(col)) return 'CHARGING';
        return 'PATHWAY';
    }

    isIntersection(col, row) {
        return this.intersections.has(`${col},${row}`);
    }

    /* ---- Dynamic Obstacle Management (Algorithm 3 & 9) ---- */
    addDynamicObstacle(col, row, durationTicks = null) {
        if (!this.isStaticallyWalkable(col, row)) return false;
        // Don't place on vital base docking zones
        if (row === CONFIG.BOTTOM_ROW && (col === CONFIG.PICKUP_COL || col === CONFIG.DROPOFF_COL)) {
            return false;
        }
        const key = `${col},${row}`;
        this.dynamicObstacles.set(key, {
            col,
            row,
            addedAt: Date.now(),
            durationTicks: durationTicks
        });
        return true;
    }

    removeDynamicObstacle(col, row) {
        const key = `${col},${row}`;
        return this.dynamicObstacles.delete(key);
    }

    toggleDynamicObstacle(col, row) {
        if (this.hasDynamicObstacle(col, row)) {
            this.removeDynamicObstacle(col, row);
            return false;
        } else {
            return this.addDynamicObstacle(col, row);
        }
    }

    clearDynamicObstacles() {
        this.dynamicObstacles.clear();
    }

    getDynamicObstaclesList() {
        return Array.from(this.dynamicObstacles.values());
    }

    /* ---- Graph Neighbor Traversal ---- */
    getRawOrthogonalNeighbors(col, row) {
        const deltas = [
            { dc: 0, dr: -1, dir: 'UP' },
            { dc: 0, dr:  1, dir: 'DOWN' },
            { dc: -1, dr: 0, dir: 'LEFT' },
            { dc:  1, dr: 0, dir: 'RIGHT' }
        ];
        const results = [];
        for (const { dc, dr, dir } of deltas) {
            const nc = col + dc;
            const nr = row + dr;
            if (this.isStaticallyWalkable(nc, nr)) {
                results.push({ col: nc, row: nr, dir });
            }
        }
        return results;
    }

    /*
     * Returns valid neighbor transitions for pathfinding.
     * Incorporates Algorithm 12 (Traffic Flow Bias in Aisles).
     */
    getNeighbors(col, row, currentHeading = null) {
        const deltas = [
            { dc: 0, dr: -1, dir: 'UP' },
            { dc: 0, dr:  1, dir: 'DOWN' },
            { dc: -1, dr: 0, dir: 'LEFT' },
            { dc:  1, dr: 0, dir: 'RIGHT' }
        ];

        const neighbors = [];
        for (const { dc, dr, dir } of deltas) {
            const nc = col + dc;
            const nr = row + dr;

            if (!this.isWalkable(nc, nr)) continue;

            // Base transition cost
            let cost = 1.0;

            // Heading change penalty (smoother kinematics)
            if (currentHeading && currentHeading !== dir) {
                cost += CONFIG.ALGO.TURN_COST;
            }

            // Algorithm 12: Traffic Flow Bias in vertical aisles
            const bias = CONFIG.ALGO.AISLE_FLOW_BIAS[nc];
            if (bias) {
                if (dir === 'UP' && bias === 'DOWN') {
                    cost += CONFIG.ALGO.FLOW_VIOLATION_PENALTY;
                } else if (dir === 'DOWN' && bias === 'UP') {
                    cost += CONFIG.ALGO.FLOW_VIOLATION_PENALTY;
                }
            }

            neighbors.push({
                col: nc,
                row: nr,
                dir: dir,
                cost: cost
            });
        }

        return neighbors;
    }

    /* ---- Shelf Access Resolution ---- */
    getShelfAccessPoints(shelfId) {
        const slot = this.shelfSlots.find(s => s.id === shelfId);
        if (!slot) return [];
        return slot.aisleAccess.filter(pt => this.isWalkable(pt.col, pt.row));
    }

    getRandomShelfSlot() {
        const idx = Math.floor(Math.random() * this.shelfSlots.length);
        return this.shelfSlots[idx];
    }
}
