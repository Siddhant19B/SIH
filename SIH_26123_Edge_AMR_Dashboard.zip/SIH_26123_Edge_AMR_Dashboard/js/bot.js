/* ============================================================
 *  BOT — Autonomous Mobile Robot (AMR) Entity & State Machine
 *  Implements Algorithm 2 (Position & Odometry) &
 *  Dynamic Priority Calculation for Conflict Arbitration
 * ============================================================ */

class AMR {
    constructor(id, name, color, haloColor, startCol, startRow) {
        this.id = id;
        this.name = name;
        this.color = color;
        this.haloColor = haloColor;

        // Discrete grid coordinates
        this.col = startCol;
        this.row = startRow;
        this.homeCol = startCol;
        this.homeRow = startRow;

        // Continuous pixel odometry (Algorithm 2)
        const initPos = CONFIG.gridToPixel(startCol, startRow);
        this.x = initPos.x;
        this.y = initPos.y;
        this.prevX = initPos.x;
        this.prevY = initPos.y;
        this.targetPixelX = initPos.x;
        this.targetPixelY = initPos.y;

        // Heading & kinematics
        this.heading = -Math.PI / 2; // Default facing UP
        this.targetHeading = -Math.PI / 2;
        this.velocity = 0;
        this.lerpProgress = 1.0;

        // State Machine
        // States: 'IDLE', 'MOVING', 'WAITING', 'PICKING_UP', 'DROPPING_OFF', 'BLOCKED', 'CHARGING'
        this.state = 'IDLE';
        this.subTickTimer = 0;

        // Active path & waypoints
        this.path = [];          // Array of { col, row, t, dir, isWait }
        this.pathIndex = 0;
        this.targetCol = startCol;
        this.targetRow = startRow;

        // Mission & Cargo
        this.currentTask = null;
        this.hasCargo = false;
        this.cargoColor = null;
        this.completedTasksCount = 0;

        // Battery & Health (Algorithm 11)
        this.battery = 100.0;
        this.isLowBattery = false;

        // Stall & Deadlock metrics (Algorithm 8)
        this.blockedTicks = 0;
        this.waitingTicks = 0;
        this.deadlockRecoveryActive = false;

        // Dynamic Priority (Algorithm 6)
        this.priority = 10.0;
        this.updatePriority();
    }

    /* ---- Dynamic Priority Calculation (Algorithm 6) ----
     * Formula: P = w_cargo * hasCargo + w_urgency * urgency + w_battery * (1 - bat/100) + w_dist * (1 / (dist + 1))
     */
    updatePriority() {
        let p = 0;
        
        // Cargo factor (40 pts)
        if (this.hasCargo) {
            p += CONFIG.ALGO.PRIORITY_WEIGHT_CARGO;
        }

        // Urgency factor (30 pts)
        const urgency = this.currentTask ? (this.currentTask.urgency || 1) : 0;
        p += (urgency / 3.0) * CONFIG.ALGO.PRIORITY_WEIGHT_URGENCY;

        // Battery distress factor (15 pts) - Bots running out of power get priority to reach charger/complete
        if (this.battery < CONFIG.ALGO.CRITICAL_BATTERY_PCT) {
            p += CONFIG.ALGO.PRIORITY_WEIGHT_BATTERY;
        } else {
            p += (1.0 - (this.battery / 100.0)) * (CONFIG.ALGO.PRIORITY_WEIGHT_BATTERY * 0.5);
        }

        // Distance factor (15 pts) - Bots closer to immediate destination get priority to clear the area
        if (this.path && this.path.length > 0) {
            const stepsRemaining = Math.max(1, this.path.length - this.pathIndex);
            p += Math.min(CONFIG.ALGO.PRIORITY_WEIGHT_DISTANCE, (10.0 / stepsRemaining) * CONFIG.ALGO.PRIORITY_WEIGHT_DISTANCE);
        }

        this.priority = Math.round(p * 10) / 10;
        return this.priority;
    }

    /* ---- Battery Physics ---- */
    drainBattery(isMoving) {
        if (this.state === 'CHARGING') {
            this.battery = Math.min(100.0, this.battery + CONFIG.BATTERY_CHARGE_RATE);
            if (this.battery >= 99.0) {
                this.state = 'IDLE';
            }
        } else {
            const drain = isMoving ? CONFIG.BATTERY_DRAIN_PER_STEP : CONFIG.BATTERY_DRAIN_IDLE;
            this.battery = Math.max(0.0, this.battery - drain);
        }
        this.isLowBattery = this.battery <= CONFIG.LOW_BATTERY;
    }

    /* ---- Path Assignment ---- */
    setTrajectory(path) {
        this.path = path || [];
        this.pathIndex = 0;
        this.blockedTicks = 0;
        this.waitingTicks = 0;
        this.deadlockRecoveryActive = false;

        if (this.path.length > 0) {
            this.state = 'MOVING';
        }
        this.updatePriority();
    }

    /* ---- P2P Telemetry Packet (Algorithm 4) ---- */
    getTelemetryPacket() {
        const nextStep = (this.path && this.pathIndex + 1 < this.path.length) 
            ? this.path[this.pathIndex + 1] 
            : { col: this.col, row: this.row };

        return {
            id: this.id,
            name: this.name,
            col: this.col,
            row: this.row,
            nextCol: nextStep.col,
            nextRow: nextStep.row,
            targetCol: this.targetCol,
            targetRow: this.targetRow,
            x: this.x,
            y: this.y,
            heading: this.heading,
            velocity: this.velocity,
            state: this.state,
            priority: this.priority,
            battery: Math.round(this.battery),
            hasCargo: this.hasCargo,
            cargoName: this.currentTask ? this.currentTask.payloadName : null,
            remainingPathLength: Math.max(0, this.path.length - this.pathIndex),
            timestamp: Date.now()
        };
    }

    /* ---- Direction to Heading Angle Helper ---- */
    _calcHeading(fromC, fromR, toC, toR) {
        if (toC > fromC) return 0;            // RIGHT (East)
        if (toC < fromC) return Math.PI;        // LEFT (West)
        if (toR > fromR) return Math.PI / 2;    // DOWN (South)
        if (toR < fromR) return -Math.PI / 2;   // UP (North)
        return this.heading;
    }

    /* ---- Smooth Odometry Interpolation (Algorithm 2 - 60FPS tick) ---- */
    updateOdometry(deltaTimeFraction) {
        // Continuous position lerp
        this.x += (this.targetPixelX - this.x) * CONFIG.ALGO.SMOOTH_LERP_FACTOR;
        this.y += (this.targetPixelY - this.y) * CONFIG.ALGO.SMOOTH_LERP_FACTOR;

        // Continuous heading angle lerp (handling angle wrap-around)
        let angleDiff = this.targetHeading - this.heading;
        while (angleDiff < -Math.PI) angleDiff += Math.PI * 2;
        while (angleDiff > Math.PI) angleDiff -= Math.PI * 2;
        this.heading += angleDiff * CONFIG.ALGO.SMOOTH_LERP_FACTOR;
    }

    /* ---- Discrete Step Advancement (Called per Simulation Tick) ---- */
    advanceStep() {
        this.updatePriority();

        // Handle stationary states
        if (this.state === 'IDLE') {
            // Check if parked at charging dock
            if (this.row === CONFIG.BOTTOM_ROW && this.col === this.homeCol && this.battery < 95) {
                this.state = 'CHARGING';
            }
            this.drainBattery(false);
            return;
        }

        if (this.state === 'CHARGING') {
            this.drainBattery(false);
            return;
        }

        if (this.state === 'PICKING_UP' || this.state === 'DROPPING_OFF') {
            this.subTickTimer--;
            this.drainBattery(false);
            if (this.subTickTimer <= 0) {
                if (this.state === 'PICKING_UP') {
                    this.hasCargo = true;
                    this.cargoColor = '#FFD166';
                    // Transition to delivering
                    this.state = 'MOVING_TO_DROPOFF';
                } else if (this.state === 'DROPPING_OFF') {
                    this.hasCargo = false;
                    this.cargoColor = null;
                    this.completedTasksCount++;
                    this.currentTask = null;
                    this.state = 'IDLE';
                }
            }
            return;
        }

        if (this.state === 'WAITING') {
            this.waitingTicks++;
            this.drainBattery(false);
            return;
        }

        if (this.state === 'BLOCKED') {
            this.blockedTicks++;
            this.drainBattery(false);
            return;
        }

        // Active path movement
        if (!this.path || this.pathIndex >= this.path.length) {
            this.state = 'IDLE';
            this.drainBattery(false);
            return;
        }

        const step = this.path[this.pathIndex];

        // Is this a planned wait-in-place step?
        if (step.isWait) {
            this.pathIndex++;
            this.drainBattery(false);
            return;
        }

        // Execute step transition
        const prevC = this.col;
        const prevR = this.row;

        this.col = step.col;
        this.row = step.row;
        this.targetHeading = this._calcHeading(prevC, prevR, this.col, this.row);

        const nextPx = CONFIG.gridToPixel(this.col, this.row);
        this.targetPixelX = nextPx.x;
        this.targetPixelY = nextPx.y;

        this.drainBattery(true);
        this.pathIndex++;
        this.waitingTicks = 0;
        this.blockedTicks = 0;

        // Check destination arrival
        if (this.pathIndex >= this.path.length) {
            this._handleArrival();
        }
    }

    _handleArrival() {
        if (this.currentTask) {
            if (this.state === 'MOVING_TO_PICKUP') {
                this.state = 'PICKING_UP';
                this.subTickTimer = CONFIG.WAYPOINT_PAUSE_TICKS;
            } else if (this.state === 'MOVING_TO_DROPOFF') {
                this.state = 'DROPPING_OFF';
                this.subTickTimer = CONFIG.WAYPOINT_PAUSE_TICKS;
            } else {
                this.state = 'IDLE';
            }
        } else {
            this.state = 'IDLE';
        }
    }
}
