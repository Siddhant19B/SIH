/* ============================================================
 *  TRAFFIC — Dynamic Obstacles, Task Auctioning & Reassignment
 *  Implements Algorithm 3 (Dynamic Obstacle Detection),
 *  Algorithm 9 (Dynamic Rerouting), Algorithm 10 (Task Auction Allocation),
 *  Algorithm 11 (Task Reassignment on Low Battery/Stall), and
 *  Algorithm 12 (Traffic Management & Directional Flow Enforcement)
 * ============================================================ */

class TrafficManager {
    constructor(grid, astarSolver, reservationTable, negotiationEngine) {
        this.grid = grid;
        this.astar = astarSolver;
        this.reservationTable = reservationTable;
        this.negotiation = negotiationEngine;

        // Active warehouse missions / order queue
        this.pendingTasks = [];
        this.activeMissions = [];
        this.completedMissions = [];

        // Task sequence ID counter
        this.taskIdSeq = 101;

        // Traffic density tracking per column (Algorithm 12)
        this.columnPassCount = new Array(CONFIG.GRID_COLS).fill(0);
    }

    /* ============================================================
     *  Algorithm 10: Task Allocation via Auction / Cost Bidding
     * ============================================================ */
    createMission(type = 'PICKUP_DELIVERY', urgency = 1) {
        const id = `ORD-${this.taskIdSeq++}`;
        const shelf = this.grid.getRandomShelfSlot();
        const accessPts = this.grid.getShelfAccessPoints(shelf.id);
        const shelfDock = accessPts.length > 0 ? accessPts[0] : { col: shelf.shelfCol, row: shelf.row };

        let from, to, payloadName;
        if (type === 'PICKUP_DELIVERY') {
            from = { col: CONFIG.PICKUP_COL, row: CONFIG.BOTTOM_ROW };
            to = shelfDock;
            payloadName = `SKU-${Math.floor(1000 + Math.random() * 9000)}`;
        } else if (type === 'DELIVERY_TO_DROPOFF') {
            from = shelfDock;
            to = { col: CONFIG.DROPOFF_COL, row: CONFIG.BOTTOM_ROW };
            payloadName = `PKG-${Math.floor(100 + Math.random() * 900)}`;
        } else {
            from = { col: CONFIG.PICKUP_COL, row: CONFIG.BOTTOM_ROW };
            to = { col: CONFIG.DROPOFF_COL, row: CONFIG.BOTTOM_ROW };
            payloadName = `EXPRESS-CARGO`;
        }

        const task = {
            id,
            type,
            urgency: urgency || Math.floor(1 + Math.random() * 3), // 1 to 3
            from,
            to,
            shelfId: shelf.id,
            payloadName,
            createdAt: Date.now(),
            assignedBotId: null,
            status: 'PENDING'
        };

        this.pendingTasks.push(task);
        this.negotiation.logEvent('P2P', `New Mission Queued: ${task.id} [${task.payloadName}] Urgency: ${task.urgency}`);
        return task;
    }

    /*
     * Bidding auction: Evaluates best fit AMR for unassigned tasks
     */
    auctionPendingTasks(bots) {
        if (this.pendingTasks.length === 0) return;

        // Iterate through pending tasks
        for (let i = this.pendingTasks.length - 1; i >= 0; i--) {
            const task = this.pendingTasks[i];

            // Only consider eligible bots: IDLE and battery > critical threshold
            const eligibleBots = bots.filter(b => b.state === 'IDLE' && b.battery > CONFIG.ALGO.CRITICAL_BATTERY_PCT);
            if (eligibleBots.length === 0) continue;

            let bestBot = null;
            let lowestCost = Infinity;

            for (const bot of eligibleBots) {
                // Bid Cost Formula:
                // Cost = dist(bot, from) * W_dist + (100 - battery) * W_battery + (bot.hasCargo ? 10 : 0)
                const dist = Math.abs(bot.col - task.from.col) + Math.abs(bot.row - task.from.row);
                const batPenalty = (100.0 - bot.battery) * CONFIG.ALGO.AUCTION_WEIGHT_BATTERY;
                const payloadPenalty = bot.hasCargo ? CONFIG.ALGO.AUCTION_WEIGHT_PAYLOAD : 0;
                const cost = (dist * CONFIG.ALGO.AUCTION_WEIGHT_DIST) + batPenalty + payloadPenalty;

                if (cost < lowestCost) {
                    lowestCost = cost;
                    bestBot = bot;
                }
            }

            if (bestBot) {
                // Award auction
                task.assignedBotId = bestBot.id;
                task.status = 'DISPATCHED';
                bestBot.currentTask = task;

                // Remove from pending
                this.pendingTasks.splice(i, 1);
                this.activeMissions.push(task);

                this.negotiation.logEvent(
                    'P2P',
                    `Auction Won: ${bestBot.name} awarded ${task.id} (Bid Cost: ${lowestCost.toFixed(1)})`,
                    bestBot.id
                );

                // Plan route from bot current location to task origin
                this.dispatchBotToTarget(bestBot, task.from.col, task.from.row, 'MOVING_TO_PICKUP');
            }
        }
    }

    dispatchBotToTarget(bot, targetCol, targetRow, targetState = 'MOVING') {
        bot.targetCol = targetCol;
        bot.targetRow = targetRow;

        const path = this.astar.findPath(
            bot.col,
            bot.row,
            targetCol,
            targetRow,
            0,
            this.reservationTable,
            bot.id,
            CONFIG.ALGO.MAX_TIME_HORIZON
        );

        if (path && path.length > 0) {
            bot.setTrajectory(path);
            bot.state = targetState;
            this.reservationTable.reservePath(bot.id, path);
            return true;
        } else {
            // Cannot find clear route right now
            bot.state = 'WAITING';
            return false;
        }
    }

    /* ============================================================
     *  Algorithm 11: Dynamic Task Reassignment
     * ============================================================ */
    checkTaskReassignments(bots) {
        for (const bot of bots) {
            if (!bot.currentTask) continue;

            let needsReassignment = false;
            let reason = '';

            // Case 1: Battery depleted below critical threshold
            if (bot.battery < CONFIG.ALGO.CRITICAL_BATTERY_PCT) {
                needsReassignment = true;
                reason = `Low Battery (${bot.battery.toFixed(0)}%)`;
            }

            // Case 2: Prolonged stall / unresolvable blockage
            if (bot.blockedTicks > CONFIG.ALGO.STALL_TIMEOUT_TICKS) {
                needsReassignment = true;
                reason = `Stall Timeout (${bot.blockedTicks} ticks)`;
            }

            if (needsReassignment) {
                const abandonedTask = bot.currentTask;
                this.negotiation.logEvent('ARBITRATION', `EMERGENCY REASSIGNMENT: ${bot.name} surrendered ${abandonedTask.id} [${reason}]`, bot.id);

                // Release bot path & task
                this.reservationTable.release(bot.id);
                bot.currentTask = null;
                bot.path = [];
                bot.state = 'MOVING';

                // Send bot to home charger at row 5
                this.dispatchBotToTarget(bot, bot.homeCol, bot.homeRow, 'MOVING');

                // Return task to pending queue for re-auction
                abandonedTask.assignedBotId = null;
                abandonedTask.status = 'PENDING';
                this.pendingTasks.unshift(abandonedTask);
            }
        }
    }

    /* ============================================================
     *  Algorithm 3 & 9: Dynamic Obstacle Detection & Rerouting
     * ============================================================ */
    scanDynamicObstaclesAndReroute(bots) {
        const dynObstacles = this.grid.getDynamicObstaclesList();
        if (dynObstacles.length === 0) return;

        for (const bot of bots) {
            if (bot.state !== 'MOVING' || !bot.path) continue;

            // Algorithm 3: Local sensor bubble detection
            for (const obs of dynObstacles) {
                const dist = Math.hypot(bot.col - obs.col, bot.row - obs.row);

                if (dist <= CONFIG.ALGO.SENSOR_RADIUS_GRID) {
                    // Check if obstacle is directly along future path
                    const pathContainsObs = bot.path.slice(bot.pathIndex).some(step => step.col === obs.col && step.row === obs.row);

                    if (pathContainsObs) {
                        this.negotiation.logEvent('COLLISION', `${bot.name} sensor detected dynamic obstacle at (${obs.col},${obs.row})!`, bot.id);

                        // Algorithm 9: Trigger Dynamic Rerouting
                        const targetStep = bot.path[bot.path.length - 1];
                        const newPath = this.astar.findPath(
                            bot.col,
                            bot.row,
                            targetStep.col,
                            targetStep.row,
                            0,
                            this.reservationTable,
                            bot.id,
                            CONFIG.ALGO.MAX_TIME_HORIZON
                        );

                        if (newPath && newPath.length > 0) {
                            bot.setTrajectory(newPath);
                            this.reservationTable.reservePath(bot.id, newPath);
                            this.negotiation.logEvent('REROUTE', `${bot.name} successfully rerouted around dynamic hazard!`, bot.id);
                        } else {
                            bot.state = 'BLOCKED';
                            bot.blockedTicks++;
                            this.negotiation.logEvent('DEADLOCK', `${bot.name} trapped by obstacle at (${obs.col},${obs.row}); holding...`, bot.id);
                        }
                        break;
                    }
                }
            }
        }
    }

    /* ============================================================
     *  Algorithm 12: Traffic Density & Aisle Flow Tracking
     * ============================================================ */
    trackTrafficFlow(bots) {
        for (const bot of bots) {
            if (bot.state === 'MOVING') {
                this.columnPassCount[bot.col]++;
            }
        }
    }
}
