/* ============================================================
 *  ASTAR — Space-Time A* Search & 4D Reservation Table
 *  Implements Algorithm 1 (Global Path Planning) &
 *  Algorithm 9 (Dynamic Rerouting with Time Reservations)
 * ============================================================ */

/* ---- Min-Heap Priority Queue for Fast A* Node Expansion ---- */
class MinHeap {
    constructor() {
        this.heap = [];
    }

    push(node) {
        this.heap.push(node);
        this._bubbleUp(this.heap.length - 1);
    }

    pop() {
        if (this.isEmpty()) return null;
        const top = this.heap[0];
        const bottom = this.heap.pop();
        if (this.heap.length > 0) {
            this.heap[0] = bottom;
            this._sinkDown(0);
        }
        return top;
    }

    isEmpty() {
        return this.heap.length === 0;
    }

    _bubbleUp(index) {
        while (index > 0) {
            const parentIdx = Math.floor((index - 1) / 2);
            if (this.heap[index].f < this.heap[parentIdx].f) {
                const tmp = this.heap[index];
                this.heap[index] = this.heap[parentIdx];
                this.heap[parentIdx] = tmp;
                index = parentIdx;
            } else {
                break;
            }
        }
    }

    _sinkDown(index) {
        const length = this.heap.length;
        while (true) {
            let leftChildIdx = 2 * index + 1;
            let rightChildIdx = 2 * index + 2;
            let swapIdx = null;

            if (leftChildIdx < length) {
                if (this.heap[leftChildIdx].f < this.heap[index].f) {
                    swapIdx = leftChildIdx;
                }
            }

            if (rightChildIdx < length) {
                if (
                    (swapIdx === null && this.heap[rightChildIdx].f < this.heap[index].f) ||
                    (swapIdx !== null && this.heap[rightChildIdx].f < this.heap[leftChildIdx].f)
                ) {
                    swapIdx = rightChildIdx;
                }
            }

            if (swapIdx === null) break;
            const tmp = this.heap[index];
            this.heap[index] = this.heap[swapIdx];
            this.heap[swapIdx] = tmp;
            index = swapIdx;
        }
    }
}

/* ---- 4D Reservation Table (Space-Time Collision Lock) ---- */
class ReservationTable {
    constructor() {
        // Vertex reservations: Map<timeStep, Map<"col,row", botId>>
        this.vertexReservations = new Map();
        
        // Edge / Swap reservations: Map<timeStep, Map<"fromCol,fromRow->toCol,toRow", botId>>
        this.edgeReservations = new Map();

        // Bot paths index: Map<botId, Array<{ col, row, t }>>
        this.botPaths = new Map();
    }

    clear() {
        this.vertexReservations.clear();
        this.edgeReservations.clear();
        this.botPaths.clear();
    }

    // Release all reservations owned by a specific AMR
    release(botId) {
        const path = this.botPaths.get(botId);
        if (!path) return;

        for (let i = 0; i < path.length; i++) {
            const step = path[i];
            const vMap = this.vertexReservations.get(step.t);
            if (vMap) {
                vMap.delete(`${step.col},${step.row}`);
                if (vMap.size === 0) this.vertexReservations.delete(step.t);
            }

            if (i > 0) {
                const prev = path[i - 1];
                const eMap = this.edgeReservations.get(step.t);
                if (eMap) {
                    eMap.delete(`${prev.col},${prev.row}->${step.col},${step.row}`);
                    if (eMap.size === 0) this.edgeReservations.delete(step.t);
                }
            }
        }

        this.botPaths.delete(botId);
    }

    // Register a full planned trajectory for an AMR into space-time
    reservePath(botId, path) {
        this.release(botId);
        if (!path || path.length === 0) return;

        this.botPaths.set(botId, path);

        for (let i = 0; i < path.length; i++) {
            const step = path[i];
            const t = step.t;

            // 1. Vertex reservation
            if (!this.vertexReservations.has(t)) {
                this.vertexReservations.set(t, new Map());
            }
            this.vertexReservations.get(t).set(`${step.col},${step.row}`, botId);

            // 2. Edge / Transition reservation
            if (i > 0) {
                const prev = path[i - 1];
                if (!this.edgeReservations.has(t)) {
                    this.edgeReservations.set(t, new Map());
                }
                this.edgeReservations.get(t).set(`${prev.col},${prev.row}->${step.col},${step.row}`, botId);
            }
        }
    }

    // Check if cell is occupied at time t by any other bot
    isVertexReserved(col, row, t, excludeBotId = null) {
        const vMap = this.vertexReservations.get(t);
        if (!vMap) return false;
        const owner = vMap.get(`${col},${row}`);
        if (owner === undefined) return false;
        if (excludeBotId !== null && owner === excludeBotId) return false;
        return true;
    }

    // Check if moving from (fromC, fromR) to (toC, toR) at time t causes a head-on swap collision
    isEdgeReserved(fromC, fromR, toC, toR, t, excludeBotId = null) {
        const eMap = this.edgeReservations.get(t);
        if (!eMap) return false;
        // Opposing bot moving in reverse direction at same time
        const opposingOwner = eMap.get(`${toC},${toR}->${fromC},${fromR}`);
        if (opposingOwner === undefined) return false;
        if (excludeBotId !== null && opposingOwner === excludeBotId) return false;
        return true;
    }

    getOccupant(col, row, t) {
        const vMap = this.vertexReservations.get(t);
        if (!vMap) return null;
        return vMap.get(`${col},${row}`) || null;
    }
}

/* ============================================================
 *  Space-Time A* Search Algorithm
 * ============================================================ */
class SpaceTimeAStar {
    constructor(grid) {
        this.grid = grid;
    }

    // Manhattan distance heuristic with directional alignment tie-breaker
    heuristic(col, row, goalCol, goalRow) {
        const dx = Math.abs(goalCol - col);
        const dy = Math.abs(goalRow - row);
        return (dx + dy) * 1.001; // nudge to favor direct paths
    }

    /*
     * Finds a conflict-free trajectory in space-time (c, r, t)
     * @param {number} startCol, startRow
     * @param {number} goalCol, goalRow
     * @param {number} startTime
     * @param {ReservationTable} reservationTable
     * @param {string} botId
     * @param {number} maxHorizon
     * @returns {Array<{ col, row, t, dir, isWait }>} or null if unreachable
     */
    findPath(startCol, startRow, goalCol, goalRow, startTime = 0, reservationTable = null, botId = null, maxHorizon = 60) {
        if (!this.grid.isWalkable(goalCol, goalRow)) {
            // Target might be an obstacle or shelf
            return null;
        }

        const openSet = new MinHeap();
        const closedSet = new Set(); // Key: "c,r,t"

        const startH = this.heuristic(startCol, startRow, goalCol, goalRow);
        const startNode = {
            col: startCol,
            row: startRow,
            t: startTime,
            g: 0,
            h: startH,
            f: startH,
            parent: null,
            dir: null,
            isWait: false
        };

        openSet.push(startNode);

        while (!openSet.isEmpty()) {
            const current = openSet.pop();

            // Goal check
            if (current.col === goalCol && current.row === goalRow) {
                return this._reconstructPath(current);
            }

            const stateKey = `${current.col},${current.row},${current.t}`;
            if (closedSet.has(stateKey)) continue;
            closedSet.add(stateKey);

            // Horizon guard
            if (current.t - startTime >= maxHorizon) continue;

            const nextT = current.t + 1;

            // 1. Consider Move Transitions to Orthogonal Neighbors
            const neighbors = this.grid.getNeighbors(current.col, current.row, current.dir);
            for (const n of neighbors) {
                // Check Space-Time vertex reservation
                if (reservationTable && reservationTable.isVertexReserved(n.col, n.row, nextT, botId)) {
                    continue; // Position occupied in time
                }

                // Check Space-Time edge / head-on swap collision
                if (reservationTable && reservationTable.isEdgeReserved(current.col, current.row, n.col, n.row, nextT, botId)) {
                    continue; // Head-on swap collision
                }

                const nextG = current.g + n.cost;
                const nextH = this.heuristic(n.col, n.row, goalCol, goalRow);
                const neighborNode = {
                    col: n.col,
                    row: n.row,
                    t: nextT,
                    g: nextG,
                    h: nextH,
                    f: nextG + nextH,
                    parent: current,
                    dir: n.dir,
                    isWait: false
                };

                const nextKey = `${n.col},${n.row},${nextT}`;
                if (!closedSet.has(nextKey)) {
                    openSet.push(neighborNode);
                }
            }

            // 2. Consider Wait-In-Place Transition (holding position for dynamic clearing)
            // Can wait if current position is free at nextT
            const waitAllowed = !reservationTable || !reservationTable.isVertexReserved(current.col, current.row, nextT, botId);
            if (waitAllowed) {
                const waitG = current.g + CONFIG.ALGO.WAIT_COST;
                const waitH = this.heuristic(current.col, current.row, goalCol, goalRow);
                const waitNode = {
                    col: current.col,
                    row: current.row,
                    t: nextT,
                    g: waitG,
                    h: waitH,
                    f: waitG + waitH,
                    parent: current,
                    dir: current.dir,
                    isWait: true
                };

                const waitKey = `${current.col},${current.row},${nextT}`;
                if (!closedSet.has(waitKey)) {
                    openSet.push(waitNode);
                }
            }
        }

        // Unreachable within horizon
        return null;
    }

    _reconstructPath(node) {
        const path = [];
        let curr = node;
        while (curr) {
            path.push({
                col: curr.col,
                row: curr.row,
                t: curr.t,
                dir: curr.dir,
                isWait: curr.isWait
            });
            curr = curr.parent;
        }
        path.reverse();
        return path;
    }
}
