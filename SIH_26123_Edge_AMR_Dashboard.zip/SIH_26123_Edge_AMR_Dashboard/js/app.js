/* ============================================================
 *  APP — UI Controller, Event Bindings & Live Telemetry Sync
 *  Wires user controls, telemetry cards, terminal logs and scenario presets
 * ============================================================ */

document.addEventListener('DOMContentLoaded', () => {
    // 1. Initialize Canvas & Simulation
    const canvas = document.getElementById('warehouse-canvas');
    if (!canvas) {
        console.error('Canvas element #warehouse-canvas not found!');
        return;
    }
    
    canvas.width = CONFIG.CANVAS_WIDTH;
    canvas.height = CONFIG.CANVAS_HEIGHT;

    const sim = new WarehouseSimulation(canvas);
    // Expose for console debugging if needed
    window.sim = sim;

    // Render initial canvas snapshot
    sim.renderer.render();

    // 2. Play / Pause / Reset Controls
    const btnPlayPause = document.getElementById('btn-play-pause');
    const playIcon = document.getElementById('play-icon');
    const playText = document.getElementById('play-text');
    const btnStep = document.getElementById('btn-step');
    const btnReset = document.getElementById('btn-reset');
    const speedSlider = document.getElementById('speed-slider');
    const speedLabel = document.getElementById('speed-val');

    function updatePlayButton() {
        if (sim.isRunning) {
            btnPlayPause.classList.add('btn-active');
            playText.textContent = 'Pause';
            playIcon.textContent = '⏸';
        } else {
            btnPlayPause.classList.remove('btn-active');
            playText.textContent = 'Run Fleet';
            playIcon.textContent = '▶';
        }
    }

    btnPlayPause.addEventListener('click', () => {
        if (sim.isRunning) {
            sim.pause();
        } else {
            sim.start();
        }
        updatePlayButton();
    });

    btnStep.addEventListener('click', () => {
        sim.pause();
        updatePlayButton();
        sim.step();
        sim.renderer.render();
        syncUI();
    });

    btnReset.addEventListener('click', () => {
        sim.reset();
        updatePlayButton();
        syncUI();
    });

    speedSlider.addEventListener('input', (e) => {
        const val = parseFloat(e.target.value);
        sim.setSpeed(val);
        speedLabel.textContent = `${val.toFixed(1)}x`;
    });

    // 3. Interactive Tool Mode Toggles
    const toolButtons = document.querySelectorAll('.tool-btn');
    toolButtons.forEach(btn => {
        btn.addEventListener('click', () => {
            toolButtons.forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            sim.interactiveMode = btn.dataset.mode;
        });
    });

    // 4. Scenario Preset Buttons
    const scenarioButtons = document.querySelectorAll('.scenario-btn');
    scenarioButtons.forEach(btn => {
        btn.addEventListener('click', () => {
            scenarioButtons.forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            const scenario = btn.dataset.scenario;
            sim.loadScenario(scenario);
            updatePlayButton();
            syncUI();
        });
    });

    // 5. Canvas Click Handler
    canvas.addEventListener('click', (e) => {
        const rect = canvas.getBoundingClientRect();
        const scaleX = canvas.width / rect.width;
        const scaleY = canvas.height / rect.height;
        const x = (e.clientX - rect.left) * scaleX;
        const y = (e.clientY - rect.top) * scaleY;

        sim.handleCanvasClick(x, y);
        syncUI();
    });

    // 6. View Layer Toggles
    const chkSensor = document.getElementById('chk-sensor');
    const chkTraj = document.getElementById('chk-traj');
    const chkConflict = document.getElementById('chk-conflict');
    const chkFlow = document.getElementById('chk-flow');

    if (chkSensor) {
        chkSensor.addEventListener('change', (e) => {
            sim.renderer.showSensorBubbles = e.target.checked;
            sim.renderer.render();
        });
    }
    if (chkTraj) {
        chkTraj.addEventListener('change', (e) => {
            sim.renderer.showTrajectories = e.target.checked;
            sim.renderer.render();
        });
    }
    if (chkConflict) {
        chkConflict.addEventListener('change', (e) => {
            sim.renderer.showConflictPredictions = e.target.checked;
            sim.renderer.render();
        });
    }
    if (chkFlow) {
        chkFlow.addEventListener('change', (e) => {
            sim.renderer.showAisleFlowArrows = e.target.checked;
            sim.renderer.render();
        });
    }

    // 7. Manual Order Dispatch Button
    const btnDispatchOrder = document.getElementById('btn-dispatch-order');
    if (btnDispatchOrder) {
        btnDispatchOrder.addEventListener('click', () => {
            const urgency = Math.floor(1 + Math.random() * 3);
            const task = sim.traffic.createMission('PICKUP_DELIVERY', urgency);
            syncUI();
        });
    }

    // 8. Terminal Log Filter & Clear
    let activeLogFilter = 'ALL';
    const logFilters = document.querySelectorAll('.terminal-filter-btn');
    logFilters.forEach(btn => {
        btn.addEventListener('click', () => {
            logFilters.forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            activeLogFilter = btn.dataset.filter;
            renderTerminalLogs();
        });
    });

    const btnClearLogs = document.getElementById('btn-clear-logs');
    if (btnClearLogs) {
        btnClearLogs.addEventListener('click', () => {
            sim.negotiation.eventLog = [];
            renderTerminalLogs();
        });
    }

    // 9. Telemetry Sync Loop (Runs every 120ms to keep DOM light and smooth)
    setInterval(() => {
        syncUI();
    }, 120);

    function syncUI() {
        renderBotCards();
        renderBenchmarkMetrics();
        renderAlgorithmBadges();
        renderTerminalLogs();
    }

    /* ---- Render Bot Telemetry Cards ---- */
    function renderBotCards() {
        const container = document.getElementById('bot-cards-container');
        if (!container) return;

        sim.bots.forEach((bot, index) => {
            let card = document.getElementById(`bot-card-${bot.id}`);
            if (!card) {
                // Create card DOM structure once
                card = document.createElement('div');
                card.id = `bot-card-${bot.id}`;
                card.className = `bot-card border-${bot.name.toLowerCase()}`;
                container.appendChild(card);
            }

            // Highlight selected bot
            if (sim.selectedBot && sim.selectedBot.id === bot.id) {
                card.classList.add('card-selected');
            } else {
                card.classList.remove('card-selected');
            }

            // Format state badge styling
            let stateBadgeClass = 'badge-idle';
            if (bot.state.includes('MOVING')) stateBadgeClass = 'badge-moving';
            else if (bot.state === 'WAITING') stateBadgeClass = 'badge-waiting';
            else if (bot.state === 'BLOCKED') stateBadgeClass = 'badge-blocked';
            else if (bot.state === 'CHARGING') stateBadgeClass = 'badge-charging';
            else if (bot.state.includes('PICK') || bot.state.includes('DROP')) stateBadgeClass = 'badge-task';

            const batColor = bot.battery > 50 ? '#10B981' : (bot.battery > 20 ? '#F59E0B' : '#EF4444');

            card.innerHTML = `
                <div class="bot-card-header">
                    <div class="bot-name-group">
                        <span class="bot-dot" style="background-color: ${bot.color}"></span>
                        <span class="bot-name">${bot.name}</span>
                        <span class="bot-tag">${bot.id}</span>
                    </div>
                    <span class="bot-state-badge ${stateBadgeClass}">${bot.state}</span>
                </div>

                <div class="bot-card-body">
                    <!-- Battery & Priority -->
                    <div class="telemetry-row">
                        <span class="telemetry-label">Battery:</span>
                        <div class="battery-bar-wrap">
                            <div class="battery-bar" style="width: ${bot.battery}%; background-color: ${batColor}"></div>
                        </div>
                        <span class="telemetry-val" style="color: ${batColor}">${Math.round(bot.battery)}%</span>
                    </div>

                    <div class="telemetry-row">
                        <span class="telemetry-label">Priority Score (A06):</span>
                        <span class="priority-score" style="color: ${bot.color}">${bot.priority.toFixed(1)}</span>
                    </div>

                    <!-- AprilTag-derived grid pose & target -->
                    <div class="telemetry-grid">
                        <div>
                            <span class="telemetry-label">AprilTag Pose:</span>
                            <span class="telemetry-val">(${bot.col}, ${bot.row})</span>
                        </div>
                        <div>
                            <span class="telemetry-label">Target:</span>
                            <span class="telemetry-val">(${bot.targetCol}, ${bot.targetRow})</span>
                        </div>
                    </div>

                    <!-- Cargo Status -->
                    <div class="telemetry-row">
                        <span class="telemetry-label">Payload:</span>
                        <span class="telemetry-val ${bot.hasCargo ? 'has-cargo' : 'no-cargo'}">
                            ${bot.hasCargo ? `📦 ${(bot.currentTask ? bot.currentTask.payloadName : 'CARGO')}` : 'None (Empty)'}
                        </span>
                    </div>

                    <!-- Tasks Completed -->
                    <div class="telemetry-row">
                        <span class="telemetry-label">Completed (A13):</span>
                        <span class="telemetry-val font-semibold">${bot.completedTasksCount}</span>
                    </div>
                </div>
            `;

            // Click card to select bot
            card.onclick = () => {
                sim.selectedBot = bot;
                sim.negotiation.logEvent('P2P', `User selected ${bot.name} via telemetry panel.`, bot.id);
                syncUI();
            };
        });
    }

    /* ---- Render Live Performance Benchmarks (A13) ---- */
    function renderBenchmarkMetrics() {
        const elDecentralized = document.getElementById('metric-decentralized-tput');
        const elBaseline = document.getElementById('metric-baseline-tput');
        const elBoost = document.getElementById('metric-boost-pct');
        const elOrders = document.getElementById('metric-total-orders');
        const elConflicts = document.getElementById('metric-conflicts-resolved');
        const elDeadlocks = document.getElementById('metric-deadlocks-avoided');
        const elAvgTime = document.getElementById('metric-avg-time');

        if (elDecentralized) elDecentralized.textContent = `${sim.metrics.decentralizedThroughput} /min`;
        if (elBaseline) elBaseline.textContent = `${sim.metrics.baselineThroughput} /min`;
        if (elBoost) elBoost.textContent = `+${sim.metrics.throughputBoostPct}%`;
        if (elOrders) elOrders.textContent = sim.metrics.totalOrdersCompleted;
        if (elConflicts) elConflicts.textContent = `${sim.metrics.conflictsResolved}`;
        if (elDeadlocks) elDeadlocks.textContent = `${sim.negotiation.intersectionLocks.size + sim.metrics.deadlocksPrevented}`;
        if (elAvgTime) elAvgTime.textContent = `${sim.metrics.averageDeliveryTimeSec.toFixed(1)}s`;

    }

    /* ---- Render Algorithm Status Badges (13 Algorithms) ---- */
    function renderAlgorithmBadges() {
        const algoPills = document.querySelectorAll('.algo-pill');
        const hasConflicts = sim.negotiation.activeConflicts.length > 0;
        const hasLocks = sim.negotiation.intersectionLocks.size > 0;
        const hasMoving = sim.bots.some(b => b.state.includes('MOVING'));

        algoPills.forEach(pill => {
            const algoNum = parseInt(pill.dataset.algo, 10);
            let active = false;

            switch (algoNum) {
                case 1: active = hasMoving; break; // Space-Time A*
                case 2: active = sim.isRunning; break; // Odometry
                case 3: active = sim.grid.dynamicObstacles.size > 0; break; // Obstacle detection
                case 4: active = sim.isRunning; break; // P2P
                case 5: active = hasConflicts; break; // Collision prediction
                case 6: active = hasConflicts; break; // Arbitration
                case 7: active = hasLocks; break; // Deadlock prevention
                case 8: active = sim.bots.some(b => b.deadlockRecoveryActive); break; // Cycle recovery
                case 9: active = sim.bots.some(b => b.state === 'BLOCKED'); break; // Reroute
                case 10: active = sim.traffic.activeMissions.length > 0; break; // Auction
                case 11: active = sim.bots.some(b => b.battery < CONFIG.ALGO.CRITICAL_BATTERY_PCT); break; // Reassignment
                case 12: active = hasMoving; break; // Traffic flow
                case 13: active = sim.metrics.totalOrdersCompleted > 0; break; // Benchmark
            }

            if (active) {
                pill.classList.add('algo-active');
            } else {
                pill.classList.remove('algo-active');
            }
        });
    }

    /* ---- Render Terminal Event Stream ---- */
    function renderTerminalLogs() {
        const terminalBody = document.getElementById('terminal-log-content');
        if (!terminalBody) return;

        let logs = sim.negotiation.getRecentLogs(35);

        if (activeLogFilter !== 'ALL') {
            logs = logs.filter(l => l.category === activeLogFilter);
        }

        terminalBody.innerHTML = logs.map(l => {
            let catClass = 'log-cat-p2p';
            if (l.category === 'COLLISION') catClass = 'log-cat-collision';
            else if (l.category === 'ARBITRATION') catClass = 'log-cat-arbitration';
            else if (l.category === 'DEADLOCK') catClass = 'log-cat-deadlock';
            else if (l.category === 'REROUTE') catClass = 'log-cat-reroute';

            return `
                <div class="terminal-line">
                    <span class="terminal-time">[${l.time}]</span>
                    <span class="terminal-cat ${catClass}">${l.category}</span>
                    <span class="terminal-msg">${l.message}</span>
                </div>
            `;
        }).join('');
    }

    // Auto-start simulation on first load after 500ms
    setTimeout(() => {
        sim.start();
        updatePlayButton();
    }, 600);
});
