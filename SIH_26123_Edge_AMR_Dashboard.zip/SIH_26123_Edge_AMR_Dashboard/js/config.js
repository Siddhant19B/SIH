/* ============================================================
 *  CONFIG — Central configuration for the warehouse simulation
 *  Implements configuration for Complete 13-Algorithm Multi-AMR Architecture
 * ============================================================ */
const CONFIG = {

    /* ---- Canvas & Dimensions ---- */
    CANVAS_WIDTH : 1040,
    CANVAS_HEIGHT: 580,

    /* ---- Grid topology ----
     *  12 columns (0‑11) × 6 rows (0‑5)
     *  Rows 0‑4 = main warehouse grid
     *  Row  5   = bottom service lane (pickup / drop‑off / charging / idle spots)
     */
    GRID_COLS: 12,
    GRID_ROWS: 6,

    /* ---- Pixel layout ---- */
    GRID_OFFSET_X       : 55,
    GRID_OFFSET_Y       : 42,
    COL_SPACING         : 86,
    ROW_SPACING         : 80,
    BOTTOM_ROW_EXTRA_GAP: 110,   // extra vertical gap before row 5

    /* ---- Theme Colours (Matching warehouse_reference.png) ---- */
    BG_COLOR      : '#808080',   // Gray industrial warehouse floor
    PATHWAY_COLOR : '#E8B930',   // Yellow safety grid pathway
    PATHWAY_DARK  : '#C49A1F',   // Pathway border & shadow
    PATHWAY_WIDTH : 14,          // Width of yellow pathway strips

    /* ---- Shelf colours & geometry ---- */
    SHELF_COLOR    : '#6B6B6B',  // Metallic rack gray
    SHELF_DARK     : '#525252',  // Shelf shadow & edge
    SHELF_ACCENT   : '#8E8E8E',  // Shelf top bevel highlight
    SHELF_TEXT_COL : '#FFFFFF',
    // 5 vertical capsule shelves between vertical aisles
    SHELF_COLS     : [1, 3, 5, 7, 9],
    SHELF_ROW_START: 1,
    SHELF_ROW_END  : 3,
    SHELF_VIS_WIDTH: 56,
    SHELF_RADIUS   : 22,

    /* ---- AprilTag Fiducial Markers (camera localization model) ---- */
    MARKER_SIZE    : 22,
    MARKER_BG      : '#FFFFFF',
    MARKER_BORDER  : '#000000',
    // Deterministic fiducial patterns used by the browser simulation; physical AMR uses an AprilTag camera.
    FIDUCIAL_SEEDS : [
        [1,0,1,1, 0,1,0,0, 1,1,1,0, 0,0,1,1],
        [0,1,1,0, 1,0,0,1, 1,1,0,1, 1,0,1,0],
        [1,1,0,0, 0,1,1,1, 1,0,1,0, 0,1,0,1],
        [0,0,1,1, 1,1,0,0, 0,1,1,0, 1,0,0,1],
        [1,0,0,1, 0,1,1,0, 1,1,0,1, 0,0,1,1],
        [0,1,0,1, 1,0,1,0, 0,1,1,1, 1,1,0,0],
    ],

    /* ---- Zones ---- */
    PICKUP_COLOR : '#6BCB47',
    DROPOFF_COLOR: '#F06868',
    PICKUP_COL   : 0,
    DROPOFF_COL  : 11,
    BOTTOM_ROW   : 5,
    ZONE_WIDTH   : 135,
    ZONE_HEIGHT  : 55,
    ZONE_RADIUS  : 14,

    /* ---- Shelf Storage Inventory ---- */
    SHELF_SLOTS: [
        { id: 'S1-T', shelfCol: 1, row: 1, label: 'Rack 1A', aisleAccess: [{ col: 0, row: 1 }, { col: 2, row: 1 }] },
        { id: 'S1-M', shelfCol: 1, row: 2, label: 'Rack 1B', aisleAccess: [{ col: 0, row: 2 }, { col: 2, row: 2 }] },
        { id: 'S1-B', shelfCol: 1, row: 3, label: 'Rack 1C', aisleAccess: [{ col: 0, row: 3 }, { col: 2, row: 3 }] },

        { id: 'S2-T', shelfCol: 3, row: 1, label: 'Rack 2A', aisleAccess: [{ col: 2, row: 1 }, { col: 4, row: 1 }] },
        { id: 'S2-M', shelfCol: 3, row: 2, label: 'Rack 2B', aisleAccess: [{ col: 2, row: 2 }, { col: 4, row: 2 }] },
        { id: 'S2-B', shelfCol: 3, row: 3, label: 'Rack 2C', aisleAccess: [{ col: 2, row: 3 }, { col: 4, row: 3 }] },

        { id: 'S3-T', shelfCol: 5, row: 1, label: 'Rack 3A', aisleAccess: [{ col: 4, row: 1 }, { col: 6, row: 1 }] },
        { id: 'S3-M', shelfCol: 5, row: 2, label: 'Rack 3B', aisleAccess: [{ col: 4, row: 2 }, { col: 6, row: 2 }] },
        { id: 'S3-B', shelfCol: 5, row: 3, label: 'Rack 3C', aisleAccess: [{ col: 4, row: 3 }, { col: 6, row: 3 }] },

        { id: 'S4-T', shelfCol: 7, row: 1, label: 'Rack 4A', aisleAccess: [{ col: 6, row: 1 }, { col: 8, row: 1 }] },
        { id: 'S4-M', shelfCol: 7, row: 2, label: 'Rack 4B', aisleAccess: [{ col: 6, row: 2 }, { col: 8, row: 2 }] },
        { id: 'S4-B', shelfCol: 7, row: 3, label: 'Rack 4C', aisleAccess: [{ col: 6, row: 3 }, { col: 8, row: 3 }] },

        { id: 'S5-T', shelfCol: 9, row: 1, label: 'Rack 5A', aisleAccess: [{ col: 8, row: 1 }, { col: 10, row: 1 }] },
        { id: 'S5-M', shelfCol: 9, row: 2, label: 'Rack 5B', aisleAccess: [{ col: 8, row: 2 }, { col: 10, row: 2 }] },
        { id: 'S5-B', shelfCol: 9, row: 3, label: 'Rack 5C', aisleAccess: [{ col: 8, row: 3 }, { col: 10, row: 3 }] },
    ],

    /* ---- Bots Fleet Specifications ---- */
    NUM_BOTS      : 4,
    BOT_COLORS    : ['#FF6B35', '#00B4D8', '#9B5DE5', '#00F5D4'], // Alpha (Orange), Beta (Cyan), Gamma (Purple), Delta (Neon Green)
    BOT_HALO_COLS : ['rgba(255,107,53,0.35)', 'rgba(0,180,216,0.35)', 'rgba(155,93,229,0.35)', 'rgba(0,245,212,0.35)'],
    BOT_NAMES     : ['Alpha', 'Beta', 'Gamma', 'Delta'],
    BOT_START_COLS: [3, 5, 7, 9],
    BOT_RADIUS    : 16,

    /* ---- 13 Multi-AMR Algorithms Parameters ---- */
    ALGO: {
        // (1) Global Path Planning (Space-Time A*)
        MAX_TIME_HORIZON: 120,       // Max time dimension steps
        WAIT_COST       : 1.2,       // Slight penalty for standing still in path
        TURN_COST       : 0.15,      // Orientation change penalty

        // (2) Position & Odometry
        SMOOTH_LERP_FACTOR: 0.18,    // Frame interpolation smoothing rate

        // (3) Local Dynamic Obstacle Detection
        SENSOR_RADIUS_GRID: 1.75,    // Detection bubble in grid cells (~150px)

        // (4) P2P Communication Mesh
        P2P_HEARTBEAT_MS  : 150,     // Inter-robot telemetry exchange interval
        P2P_MAX_RANGE_GRID: 8.0,     // Ad-hoc WiFi/UWB mesh range

        // (5) Collision Prediction (TTC)
        TTC_LOOKAHEAD_STEPS: 4,      // Steps forward to check potential trajectory clashes
        MIN_SAFE_DISTANCE  : 1.1,    // Grid unit minimum safety bubble

        // (6) Conflict Resolution Weights
        PRIORITY_WEIGHT_CARGO   : 40, // Base boost if carrying order
        PRIORITY_WEIGHT_URGENCY : 30, // Order priority level (1..3)
        PRIORITY_WEIGHT_BATTERY : 15, // Low battery gets passage
        PRIORITY_WEIGHT_DISTANCE: 15, // Closer to goal gets priority

        // (7) Deadlock Prevention
        INTERSECTION_LOCK_STEPS: 2,  // Reservation window for node entry
        
        // (8) Deadlock Recovery
        CYCLE_DETECTION_TICKS  : 4,  // Ticks stationary while blocked to trigger cycle check
        DEADLOCK_BACKOFF_TICKS : 3,  // Yield time before secondary reroute

        // (9) Dynamic Rerouting
        MAX_REROUTE_ATTEMPTS   : 5,
        DETOUR_PENALTY         : 1.5,

        // (10) Task Allocation (Auction / Cost model)
        AUCTION_WEIGHT_DIST    : 1.0,
        AUCTION_WEIGHT_BATTERY : 0.4,
        AUCTION_WEIGHT_PAYLOAD : 10.0,

        // (11) Task Reassignment
        CRITICAL_BATTERY_PCT   : 15, // Reroute to charger and yield mission
        STALL_TIMEOUT_TICKS    : 18, // If stuck without progress, drop order

        // (12) Traffic Management (Aisle Directional Biasing)
        // Vertical aisles: 0=down, 2=up, 4=down, 6=up, 8=down, 10=up, 11=down
        AISLE_FLOW_BIAS: {
            0 : 'DOWN',
            2 : 'UP',
            4 : 'DOWN',
            6 : 'UP',
            8 : 'DOWN',
            10: 'UP',
            11: 'DOWN'
        },
        FLOW_VIOLATION_PENALTY: 2.5, // Extra cost in A* for counter-flow navigation

        // (13) Performance Comparison
        BENCHMARK_WINDOW_MS: 30000,
    },

    /* ---- Battery & Physics ---- */
    BATTERY_DRAIN_PER_STEP: 0.35,  // % drain per movement step
    BATTERY_DRAIN_IDLE    : 0.05,  // % drain while standing
    BATTERY_CHARGE_RATE   : 1.5,   // % charge per tick in home/charging spot
    LOW_BATTERY           : 18,    // UI alert warning threshold

    /* ---- Simulation Timing ---- */
    SIM_STEP_MS         : 400,     // Base discrete logic step interval in ms (at 1x speed)
    SUB_TICK_FPS        : 60,      // Canvas rendering framerate
    WAYPOINT_PAUSE_TICKS: 3,       // Pause ticks when picking up or dropping off

    /* ---- Coordinate Mapping Helpers ---- */
    gridToPixel(col, row) {
        const x = CONFIG.GRID_OFFSET_X + col * CONFIG.COL_SPACING;
        const y = row <= 4
            ? CONFIG.GRID_OFFSET_Y + row * CONFIG.ROW_SPACING
            : CONFIG.GRID_OFFSET_Y + 4 * CONFIG.ROW_SPACING + CONFIG.BOTTOM_ROW_EXTRA_GAP;
        return { x, y };
    },

    pixelToGrid(px, py) {
        // Reverse mapping with snap-to-nearest grid cell
        let bestCol = 0, bestRow = 0, minDist = Infinity;
        for (let c = 0; c < CONFIG.GRID_COLS; c++) {
            for (let r = 0; r < CONFIG.GRID_ROWS; r++) {
                const pt = CONFIG.gridToPixel(c, r);
                const d = Math.hypot(pt.x - px, pt.y - py);
                if (d < minDist) {
                    minDist = d;
                    bestCol = c;
                    bestRow = r;
                }
            }
        }
        return { col: bestCol, row: bestRow, distancePx: minDist };
    }
};

// Freeze config in production to prevent accidental state contamination
if (typeof Object.freeze === 'function') {
    Object.freeze(CONFIG.ALGO);
    Object.freeze(CONFIG.SHELF_COLS);
}
