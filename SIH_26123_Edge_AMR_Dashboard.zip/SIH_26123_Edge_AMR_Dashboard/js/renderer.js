/* ============================================================
 *  RENDERER — High-Fidelity Canvas 2D Warehouse Visualization
 *  Faithfully matches warehouse_reference.png layout & aesthetics
 * ============================================================ */

class WarehouseRenderer {
    constructor(canvas, grid, bots, negotiation, traffic) {
        this.canvas = canvas;
        this.ctx = canvas.getContext('2d');
        this.grid = grid;
        this.bots = bots;
        this.negotiation = negotiation;
        this.traffic = traffic;

        // View options
        this.showSensorBubbles = true;
        this.showTrajectories = true;
        this.showConflictPredictions = true;
        this.showAisleFlowArrows = true;

        // Animation phase
        this.pulsePhase = 0;

        // Precompute AprilTag-style fiducial patterns for consistent deterministic look
        this.aprilTagPatterns = this._generateAprilTagPatterns();
    }

    _generateAprilTagPatterns() {
        const patterns = new Map();
        for (let c = 0; c < CONFIG.GRID_COLS; c++) {
            for (let r = 0; r < CONFIG.GRID_ROWS; r++) {
                // Generate deterministic 4x4 bit pattern based on coordinates
                const bits = [];
                let seed = (c * 17 + r * 31 + 7) & 0xFFFF;
                for (let i = 0; i < 16; i++) {
                    seed = (seed * 1103515245 + 12345) & 0x7FFFFFFF;
                    bits.push((seed >> 16) % 2);
                }
                patterns.set(`${c},${r}`, bits);
            }
        }
        return patterns;
    }

    /* ---- Main Render Loop (called at 60 FPS) ---- */
    render() {
        this.pulsePhase = (this.pulsePhase + 0.05) % (Math.PI * 2);

        const ctx = this.ctx;
        const w = this.canvas.width;
        const h = this.canvas.height;

        ctx.clearRect(0, 0, w, h);

        // 1. Warehouse Concrete Floor Base
        this.drawFloor(ctx, w, h);

        // 2. Yellow Safety Pathway Grid
        this.drawPathways(ctx);

        // 3. AprilTag Fiducial Markers at Intersections
        this.drawFiducialMarkers(ctx);

        // 4. Vertical Storage Capsule Shelves
        this.drawShelves(ctx);

        // 5. Pickup & Drop-Off Zones
        this.drawZones(ctx);

        // 6. Charging / Home Pads
        this.drawChargingBays(ctx);

        // 7. Aisle Flow Direction Indicators (Algorithm 12)
        if (this.showAisleFlowArrows) {
            this.drawAisleFlowArrows(ctx);
        }

        // 8. Dynamic Obstacles (Algorithm 3)
        this.drawDynamicObstacles(ctx);

        // 9. Intersection Locks (Algorithm 7)
        this.drawIntersectionLocks(ctx);

        // 10. Trajectory Vectors & Future Paths
        if (this.showTrajectories) {
            this.drawTrajectories(ctx);
        }

        // 11. Predicted Conflict Hotspots (Algorithm 5)
        if (this.showConflictPredictions) {
            this.drawConflictHotspots(ctx);
        }

        // 12. AMR Fleet Entities (Algorithm 2 & Heading)
        this.drawBots(ctx);
    }

    /* ---- 1. Floor Background ---- */
    drawFloor(ctx, w, h) {
        // Industrial smooth concrete gray
        ctx.fillStyle = CONFIG.BG_COLOR;
        ctx.fillRect(0, 0, w, h);

        // Subtle industrial floor grid texture
        ctx.strokeStyle = 'rgba(255, 255, 255, 0.035)';
        ctx.lineWidth = 1;
        const step = 20;
        ctx.beginPath();
        for (let x = 0; x <= w; x += step) {
            ctx.moveTo(x, 0);
            ctx.lineTo(x, h);
        }
        for (let y = 0; y <= h; y += step) {
            ctx.moveTo(0, y);
            ctx.lineTo(w, y);
        }
        ctx.stroke();

        // Edge vignette
        const grad = ctx.createRadialGradient(w/2, h/2, w/4, w/2, h/2, w/1.2);
        grad.addColorStop(0, 'rgba(0,0,0,0)');
        grad.addColorStop(1, 'rgba(0,0,0,0.22)');
        ctx.fillStyle = grad;
        ctx.fillRect(0, 0, w, h);
    }

    /* ---- 2. Yellow Grid Pathways ---- */
    drawPathways(ctx) {
        ctx.save();
        const pWidth = CONFIG.PATHWAY_WIDTH;

        // Draw darker pathway border
        ctx.strokeStyle = CONFIG.PATHWAY_DARK;
        ctx.lineWidth = pWidth + 3;
        ctx.lineCap = 'square';
        ctx.lineJoin = 'miter';
        this._tracePathwayLines(ctx);
        ctx.stroke();

        // Draw vibrant yellow pathway core
        ctx.strokeStyle = CONFIG.PATHWAY_COLOR;
        ctx.lineWidth = pWidth;
        this._tracePathwayLines(ctx);
        ctx.stroke();

        ctx.restore();
    }

    _tracePathwayLines(ctx) {
        ctx.beginPath();

        // Horizontal cross-aisles:
        // Row 0 (Top aisle: Col 0 to 11)
        const p0_start = CONFIG.gridToPixel(0, 0);
        const p0_end = CONFIG.gridToPixel(CONFIG.GRID_COLS - 1, 0);
        ctx.moveTo(p0_start.x, p0_start.y);
        ctx.lineTo(p0_end.x, p0_end.y);

        // Row 4 (Lower cross-aisle: Col 0 to 11)
        const p4_start = CONFIG.gridToPixel(0, 4);
        const p4_end = CONFIG.gridToPixel(CONFIG.GRID_COLS - 1, 4);
        ctx.moveTo(p4_start.x, p4_start.y);
        ctx.lineTo(p4_end.x, p4_end.y);

        // Row 5 (Bottom service lane: Col 0 to 11)
        const p5_start = CONFIG.gridToPixel(0, 5);
        const p5_end = CONFIG.gridToPixel(CONFIG.GRID_COLS - 1, 5);
        ctx.moveTo(p5_start.x, p5_start.y);
        ctx.lineTo(p5_end.x, p5_end.y);

        // Vertical aisles:
        // Columns 0, 2, 4, 6, 8, 10, 11 (running from row 0 down to row 5)
        const verticalAisles = [0, 2, 4, 6, 8, 10, 11];
        for (const col of verticalAisles) {
            const topPt = CONFIG.gridToPixel(col, 0);
            const botPt = CONFIG.gridToPixel(col, 5);
            ctx.moveTo(topPt.x, topPt.y);
            ctx.lineTo(botPt.x, botPt.y);
        }

        // Shelf access connection spurs at Rows 1, 2, 3 connecting aisles
        for (let r = 1; r <= 3; r++) {
            // Horizontal line segment connecting outer edge col 0 to col 11
            // (Passes behind shelves, shelves render on top as in reference)
            const rStart = CONFIG.gridToPixel(0, r);
            const rEnd = CONFIG.gridToPixel(CONFIG.GRID_COLS - 1, r);
            ctx.moveTo(rStart.x, rStart.y);
            ctx.lineTo(rEnd.x, rEnd.y);
        }
    }

    /* ---- 3. AprilTag Markers ---- */
    drawFiducialMarkers(ctx) {
        ctx.save();
        const size = CONFIG.MARKER_SIZE;
        const half = size / 2;

        for (let c = 0; c < CONFIG.GRID_COLS; c++) {
            for (let r = 0; r < CONFIG.GRID_ROWS; r++) {
                // Don't render marker inside shelf bodies
                if (this.grid.isShelf(c, r)) continue;

                // Markers sit on intersections or key nodes
                const pt = CONFIG.gridToPixel(c, r);

                // Marker Outer White Border
                ctx.fillStyle = CONFIG.MARKER_BG;
                ctx.fillRect(pt.x - half, pt.y - half, size, size);

                // Marker Black Inner Housing
                const innerSize = size - 4;
                ctx.fillStyle = CONFIG.MARKER_BORDER;
                ctx.fillRect(pt.x - half + 2, pt.y - half + 2, innerSize, innerSize);

                // Procedural 4x4 ArUco Bit Grid
                const bits = this.aprilTagPatterns.get(`${c},${r}`) || [];
                const bitCell = (innerSize - 2) / 4;

                ctx.fillStyle = '#FFFFFF';
                for (let by = 0; by < 4; by++) {
                    for (let bx = 0; bx < 4; bx++) {
                        const bitVal = bits[by * 4 + bx];
                        if (bitVal === 1) {
                            ctx.fillRect(
                                pt.x - half + 3 + bx * bitCell,
                                pt.y - half + 3 + by * bitCell,
                                bitCell,
                                bitCell
                            );
                        }
                    }
                }
            }
        }
        ctx.restore();
    }

    /* ---- 4. Vertical Storage Capsule Shelves ---- */
    drawShelves(ctx) {
        ctx.save();
        const width = CONFIG.SHELF_VIS_WIDTH;
        const radius = CONFIG.SHELF_RADIUS;

        for (const col of CONFIG.SHELF_COLS) {
            const topNode = CONFIG.gridToPixel(col, CONFIG.SHELF_ROW_START);
            const botNode = CONFIG.gridToPixel(col, CONFIG.SHELF_ROW_END);

            const x = topNode.x - width / 2;
            const y = topNode.y - 25;
            const h = (botNode.y - topNode.y) + 50;

            // Shelf drop shadow
            ctx.shadowColor = 'rgba(0,0,0,0.45)';
            ctx.shadowBlur = 10;
            ctx.shadowOffsetX = 3;
            ctx.shadowOffsetY = 4;

            // Metallic Capsule Body
            ctx.fillStyle = CONFIG.SHELF_COLOR;
            this._roundRect(ctx, x, y, width, h, radius);
            ctx.fill();

            // Reset shadow
            ctx.shadowColor = 'transparent';
            ctx.shadowBlur = 0;
            ctx.shadowOffsetX = 0;
            ctx.shadowOffsetY = 0;

            // Metallic Bevel Border
            ctx.strokeStyle = CONFIG.SHELF_DARK;
            ctx.lineWidth = 3;
            this._roundRect(ctx, x, y, width, h, radius);
            ctx.stroke();

            // Shelf compartments / dividers inside capsule
            ctx.strokeStyle = '#4A4A4A';
            ctx.lineWidth = 1.5;
            const slotCount = 3;
            const slotHeight = h / slotCount;
            for (let s = 1; s < slotCount; s++) {
                const lineY = y + s * slotHeight;
                ctx.beginPath();
                ctx.moveTo(x + 6, lineY);
                ctx.lineTo(x + width - 6, lineY);
                ctx.stroke();
            }

            // Vertical "SHELF" Embossed Text
            ctx.save();
            ctx.translate(topNode.x, y + h / 2);
            ctx.rotate(-Math.PI / 2);
            ctx.fillStyle = CONFIG.SHELF_TEXT_COL;
            ctx.font = 'bold 15px "Inter", "Segoe UI", Arial, sans-serif';
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            ctx.letterSpacing = '4px';
            ctx.fillText(`SHELF ${CONFIG.SHELF_COLS.indexOf(col) + 1}`, 0, 0);
            ctx.restore();
        }
        ctx.restore();
    }

    /* ---- 5. Pickup & Drop-Off Zones ---- */
    drawZones(ctx) {
        ctx.save();
        const zw = CONFIG.ZONE_WIDTH;
        const zh = CONFIG.ZONE_HEIGHT;
        const zr = CONFIG.ZONE_RADIUS;

        // 1. PICKUP ZONE (Col 0, Row 5 - Bottom Left)
        const pPt = CONFIG.gridToPixel(CONFIG.PICKUP_COL, CONFIG.BOTTOM_ROW);
        const px = pPt.x - zw / 2;
        const py = pPt.y - zh / 2;

        ctx.shadowColor = 'rgba(107, 203, 71, 0.4)';
        ctx.shadowBlur = 12;
        ctx.fillStyle = CONFIG.PICKUP_COLOR;
        this._roundRect(ctx, px, py, zw, zh, zr);
        ctx.fill();

        ctx.strokeStyle = '#529E36';
        ctx.lineWidth = 3;
        this._roundRect(ctx, px, py, zw, zh, zr);
        ctx.stroke();

        // Pickup text
        ctx.shadowColor = 'transparent';
        ctx.fillStyle = '#FFFFFF';
        ctx.font = 'bold 13px "Inter", "Segoe UI", Arial, sans-serif';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText('PICKUP ZONE', pPt.x, pPt.y);

        // 2. DROP-OFF ZONE (Col 11, Row 5 - Bottom Right)
        const dPt = CONFIG.gridToPixel(CONFIG.DROPOFF_COL, CONFIG.BOTTOM_ROW);
        const dx = dPt.x - zw / 2;
        const dy = dPt.y - zh / 2;

        ctx.shadowColor = 'rgba(240, 104, 104, 0.4)';
        ctx.shadowBlur = 12;
        ctx.fillStyle = CONFIG.DROPOFF_COLOR;
        this._roundRect(ctx, dx, dy, zw, zh, zr);
        ctx.fill();

        ctx.strokeStyle = '#C44E4E';
        ctx.lineWidth = 3;
        this._roundRect(ctx, dx, dy, zw, zh, zr);
        ctx.stroke();

        // Drop-off text
        ctx.shadowColor = 'transparent';
        ctx.fillStyle = '#FFFFFF';
        ctx.font = 'bold 13px "Inter", "Segoe UI", Arial, sans-serif';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText('DROP-OFF ZONE', dPt.x, dPt.y);

        ctx.restore();
    }

    /* ---- 6. Charging Bays (Bottom Row) ---- */
    drawChargingBays(ctx) {
        ctx.save();
        for (let i = 0; i < CONFIG.BOT_START_COLS.length; i++) {
            const col = CONFIG.BOT_START_COLS[i];
            const pt = CONFIG.gridToPixel(col, CONFIG.BOTTOM_ROW);

            // Charger docking ring
            ctx.strokeStyle = 'rgba(255, 255, 255, 0.35)';
            ctx.lineWidth = 1.5;
            ctx.setLineDash([4, 4]);
            ctx.beginPath();
            ctx.arc(pt.x, pt.y, 22, 0, Math.PI * 2);
            ctx.stroke();
            ctx.setLineDash([]);

            // Mini battery symbol
            ctx.fillStyle = 'rgba(255, 255, 255, 0.5)';
            ctx.font = '10px "Inter", Arial, sans-serif';
            ctx.textAlign = 'center';
            ctx.textBaseline = 'bottom';
            ctx.fillText(`DOCK ${i+1}`, pt.x, pt.y - 24);
        }
        ctx.restore();
    }

    /* ---- 7. Aisle Flow Direction Indicators (Algorithm 12) ---- */
    drawAisleFlowArrows(ctx) {
        ctx.save();
        ctx.fillStyle = 'rgba(0, 0, 0, 0.35)';

        for (const [colStr, dir] of Object.entries(CONFIG.ALGO.AISLE_FLOW_BIAS)) {
            const col = parseInt(colStr, 10);
            // Draw arrows along rows 1, 2, 3
            for (let r = 1; r <= 3; r++) {
                const pt = CONFIG.gridToPixel(col, r);
                this._drawArrowHead(ctx, pt.x, pt.y + (dir === 'UP' ? -10 : 10), dir);
            }
        }
        ctx.restore();
    }

    _drawArrowHead(ctx, x, y, dir) {
        const size = 5;
        ctx.save();
        ctx.translate(x, y);
        if (dir === 'UP') {
            ctx.rotate(0);
        } else if (dir === 'DOWN') {
            ctx.rotate(Math.PI);
        }
        ctx.beginPath();
        ctx.moveTo(0, -size);
        ctx.lineTo(size, size);
        ctx.lineTo(-size, size);
        ctx.closePath();
        ctx.fill();
        ctx.restore();
    }

    /* ---- 8. Dynamic Obstacles (Algorithm 3) ---- */
    drawDynamicObstacles(ctx) {
        const obstacles = this.grid.getDynamicObstaclesList();
        if (obstacles.length === 0) return;

        ctx.save();
        for (const obs of obstacles) {
            const pt = CONFIG.gridToPixel(obs.col, obs.row);

            // Hazard boundary pulse
            const pulse = Math.sin(this.pulsePhase * 3) * 3;
            ctx.shadowColor = '#FF9F1C';
            ctx.shadowBlur = 10 + pulse;

            // Hazard warning diamond
            const s = 18;
            ctx.fillStyle = '#FF9F1C';
            ctx.beginPath();
            ctx.moveTo(pt.x, pt.y - s);
            ctx.lineTo(pt.x + s, pt.y);
            ctx.lineTo(pt.x, pt.y + s);
            ctx.lineTo(pt.x - s, pt.y);
            ctx.closePath();
            ctx.fill();

            // Black diagonal hazard stripes
            ctx.strokeStyle = '#000000';
            ctx.lineWidth = 2.5;
            ctx.beginPath();
            ctx.moveTo(pt.x - 7, pt.y - 7);
            ctx.lineTo(pt.x + 7, pt.y + 7);
            ctx.moveTo(pt.x - 7, pt.y + 7);
            ctx.lineTo(pt.x + 7, pt.y - 7);
            ctx.stroke();

            // Label
            ctx.shadowColor = 'transparent';
            ctx.fillStyle = '#FFFFFF';
            ctx.font = 'bold 9px Arial';
            ctx.textAlign = 'center';
            ctx.fillText('OBSTACLE', pt.x, pt.y + s + 11);
        }
        ctx.restore();
    }

    /* ---- 9. Intersection Locks (Algorithm 7) ---- */
    drawIntersectionLocks(ctx) {
        ctx.save();
        for (const [key, lock] of this.negotiation.intersectionLocks.entries()) {
            const [c, r] = key.split(',').map(Number);
            const pt = CONFIG.gridToPixel(c, r);

            // Yellow lock ring
            ctx.strokeStyle = '#FFE66D';
            ctx.lineWidth = 2;
            ctx.setLineDash([3, 3]);
            ctx.beginPath();
            ctx.arc(pt.x, pt.y, 18, 0, Math.PI * 2);
            ctx.stroke();
            ctx.setLineDash([]);

            // Lock symbol
            ctx.fillStyle = '#FFE66D';
            ctx.font = '10px Arial';
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            ctx.fillText('🔒', pt.x, pt.y);
        }
        ctx.restore();
    }

    /* ---- 10. Trajectories & Planned Vectors ---- */
    drawTrajectories(ctx) {
        ctx.save();
        for (const bot of this.bots) {
            if (!bot.path || bot.path.length <= 1) continue;

            ctx.strokeStyle = bot.color;
            ctx.lineWidth = 2.5;
            ctx.setLineDash([6, 5]);

            ctx.beginPath();
            ctx.moveTo(bot.x, bot.y);

            for (let i = bot.pathIndex; i < bot.path.length; i++) {
                const step = bot.path[i];
                const pt = CONFIG.gridToPixel(step.col, step.row);
                ctx.lineTo(pt.x, pt.y);
            }
            ctx.stroke();

            // Destination target dot
            const dest = bot.path[bot.path.length - 1];
            const destPt = CONFIG.gridToPixel(dest.col, dest.row);
            ctx.setLineDash([]);
            ctx.fillStyle = bot.color;
            ctx.beginPath();
            ctx.arc(destPt.x, destPt.y, 5, 0, Math.PI * 2);
            ctx.fill();
        }
        ctx.restore();
    }

    /* ---- 11. Conflict Hotspots (Algorithm 5) ---- */
    drawConflictHotspots(ctx) {
        const conflicts = this.negotiation.activeConflicts;
        if (conflicts.length === 0) return;

        ctx.save();
        for (const c of conflicts) {
            const pt = CONFIG.gridToPixel(c.col, c.row);
            const pulse = Math.abs(Math.sin(this.pulsePhase * 4)) * 8;

            // Red warning aura
            ctx.fillStyle = 'rgba(255, 68, 68, 0.45)';
            ctx.beginPath();
            ctx.arc(pt.x, pt.y, 20 + pulse, 0, Math.PI * 2);
            ctx.fill();

            // Conflict warning badge
            ctx.fillStyle = '#FF3B30';
            ctx.strokeStyle = '#FFFFFF';
            ctx.lineWidth = 2;
            ctx.beginPath();
            ctx.arc(pt.x, pt.y, 11, 0, Math.PI * 2);
            ctx.fill();
            ctx.stroke();

            ctx.fillStyle = '#FFFFFF';
            ctx.font = 'bold 11px Arial';
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            ctx.fillText('!', pt.x, pt.y);

            // TTC text
            ctx.fillStyle = '#FF3B30';
            ctx.font = 'bold 10px Arial';
            ctx.fillText(`TTC: ${c.ttcSteps}`, pt.x, pt.y - 18);
        }
        ctx.restore();
    }

    /* ---- 12. AMR Fleet Entities ---- */
    drawBots(ctx) {
        ctx.save();
        const r = CONFIG.BOT_RADIUS;

        for (const bot of this.bots) {
            const bx = bot.x;
            const by = bot.y;

            // 1. Local Sensor Bubble Radar (Algorithm 3)
            if (this.showSensorBubbles && bot.state === 'MOVING') {
                const sensorRadius = CONFIG.ALGO.SENSOR_RADIUS_GRID * CONFIG.COL_SPACING * 0.9;
                ctx.strokeStyle = bot.haloColor;
                ctx.lineWidth = 1;
                ctx.setLineDash([3, 4]);
                ctx.beginPath();
                ctx.arc(bx, by, sensorRadius, 0, Math.PI * 2);
                ctx.stroke();
                ctx.setLineDash([]);
            }

            // 2. Outer Halo Glow
            ctx.fillStyle = bot.haloColor;
            const haloPulse = (bot.state === 'MOVING') ? (Math.sin(this.pulsePhase * 3) * 3) : 0;
            ctx.beginPath();
            ctx.arc(bx, by, r + 7 + haloPulse, 0, Math.PI * 2);
            ctx.fill();

            // 3. Main AMR Circular Chassis
            ctx.shadowColor = 'rgba(0,0,0,0.5)';
            ctx.shadowBlur = 8;
            ctx.shadowOffsetY = 3;
            ctx.fillStyle = bot.color;
            ctx.beginPath();
            ctx.arc(bx, by, r, 0, Math.PI * 2);
            ctx.fill();

            // Metallic chassis outer rim
            ctx.shadowColor = 'transparent';
            ctx.strokeStyle = '#FFFFFF';
            ctx.lineWidth = 2.2;
            ctx.beginPath();
            ctx.arc(bx, by, r, 0, Math.PI * 2);
            ctx.stroke();

            // 4. Heading Direction Wedge (Algorithm 2 Odometry)
            ctx.save();
            ctx.translate(bx, by);
            ctx.rotate(bot.heading);
            ctx.fillStyle = '#FFFFFF';
            ctx.beginPath();
            ctx.moveTo(r - 1, 0);
            ctx.lineTo(r - 7, -4);
            ctx.lineTo(r - 7, 4);
            ctx.closePath();
            ctx.fill();
            ctx.restore();

            // 5. Bot ID / Symbol in Center
            ctx.fillStyle = '#FFFFFF';
            ctx.font = 'bold 12px "Inter", Arial, sans-serif';
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            const symbol = bot.name[0]; // 'A', 'B', 'G', 'D'
            ctx.fillText(symbol, bx, by);

            // 6. Cargo Visualization
            if (bot.hasCargo) {
                ctx.fillStyle = bot.cargoColor || '#FFD166';
                ctx.strokeStyle = '#C49A1F';
                ctx.lineWidth = 1.5;
                ctx.fillRect(bx - 7, by - 7, 14, 14);
                ctx.strokeRect(bx - 7, by - 7, 14, 14);
            }

            // 7. Mini State / Battery Indicators below Chassis
            this._drawBotMiniBadges(ctx, bot, bx, by + r + 5);
        }
        ctx.restore();
    }

    _drawBotMiniBadges(ctx, bot, x, y) {
        // Battery bar
        const bw = 24;
        const bh = 4;
        ctx.fillStyle = 'rgba(0,0,0,0.6)';
        ctx.fillRect(x - bw/2, y, bw, bh);

        const batColor = bot.battery > 50 ? '#6BCB47' : (bot.battery > 20 ? '#FFD166' : '#FF4B4B');
        ctx.fillStyle = batColor;
        ctx.fillRect(x - bw/2, y, (bot.battery / 100) * bw, bh);

        // State Pill
        let stateTag = bot.state.slice(0, 4);
        if (bot.state === 'MOVING_TO_PICKUP') stateTag = 'PICK';
        if (bot.state === 'MOVING_TO_DROPOFF') stateTag = 'DELV';
        if (bot.deadlockRecoveryActive) stateTag = 'RCVR';

        ctx.fillStyle = 'rgba(15, 23, 42, 0.85)';
        ctx.fillRect(x - 16, y + 6, 32, 11);
        ctx.fillStyle = '#E2E8F0';
        ctx.font = 'bold 8px Arial';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(stateTag, x, y + 11);
    }

    /* ---- Helper: Rounded Rectangle Path ---- */
    _roundRect(ctx, x, y, width, height, radius) {
        ctx.beginPath();
        ctx.moveTo(x + radius, y);
        ctx.lineTo(x + width - radius, y);
        ctx.quadraticCurveTo(x + width, y, x + width, y + radius);
        ctx.lineTo(x + width, y + height - radius);
        ctx.quadraticCurveTo(x + width, y + height, x + width - radius, y + height);
        ctx.lineTo(x + radius, y + height);
        ctx.quadraticCurveTo(x, y + height, x, y + height - radius);
        ctx.lineTo(x, y + radius);
        ctx.quadraticCurveTo(x, y, x + radius, y);
        ctx.closePath();
    }
}
