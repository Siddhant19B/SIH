/* ============================================================
 *  NEGOTIATION — P2P Mesh, Conflict Arbitration, Deadlock Handling
 *  Implements Algorithm 4 (P2P Comms), Algorithm 5 (Collision Prediction/TTC),
 *  Algorithm 6 (Conflict Resolution), Algorithm 7 (Deadlock Prevention),
 *  and Algorithm 8 (Deadlock Recovery via Wait-For Graph Cycles)
 * ============================================================ */

class NegotiationEngine {
    constructor(grid, reservationTable) {
        this.grid = grid;
        this.reservationTable = reservationTable;

        // Terminal event log for UI stream
        this.eventLog = [];
        this.maxLogLength = 120;

        // Algorithm 7: Intersection Lock Points
        // Map<"col,row", { botId: string, acquiredTick: number, expiresTick: number }>
        this.intersectionLocks = new Map();

        // Algorithm 8: Wait-For Graph for Cycle Detection
        // Adjacency Map<botId, Set<waitingOnBotId>>
        this.waitForGraph = new Map();

        // Active conflict markers for canvas rendering
        this.activeConflicts = [];
    }

    logEvent(category, message, botId = null) {
        const timeStr = new Date().toLocaleTimeString('en-US', { hour12: false, hour: '2-digit', minute:'2-digit', second:'2-digit' });
        const entry = {
            id: Date.now() + Math.random(),
            time: timeStr,
            category, // 'P2P', 'COLLISION', 'ARBITRATION', 'DEADLOCK', 'REROUTE'
            message,
            botId
        };
        this.eventLog.unshift(entry);
        if (this.eventLog.length > this.maxLogLength) {
            this.eventLog.pop();
        }
        return entry;
    }

    getRecentLogs(limit = 20) {
        return this.eventLog.slice(0, limit);
    }

    /* ============================================================
     *  Algorithm 4: Robot-to-Robot (P2P) Communication Exchange
     * ============================================================ */
    broadcastP2PTelemetry(bots) {
        const telemetryMap = new Map();
        for (const bot of bots) {
            telemetryMap.set(bot.id, bot.getTelemetryPacket());
        }

        // P2P ad-hoc range check
        for (let i = 0; i < bots.length; i++) {
            for (let j = i + 1; j < bots.length; j++) {
                const b1 = bots[i];
                const b2 = bots[j];
                const dist = Math.hypot(b1.col - b2.col, b1.row - b2.row);

                if (dist <= CONFIG.ALGO.P2P_MAX_RANGE_GRID) {
                    // Packets exchanged successfully in mesh
                    // b1 receives b2, b2 receives b1
                }
            }
        }
        return telemetryMap;
    }

    /* ============================================================
     *  Algorithm 5: Collision Prediction & Time-To-Collision (TTC)
     * ============================================================ */
    predictCollisions(bots, currentTick) {
        this.activeConflicts = [];
        const conflicts = [];

        for (let i = 0; i < bots.length; i++) {
            for (let j = i + 1; j < bots.length; j++) {
                const b1 = bots[i];
                const b2 = bots[j];

                // Check upcoming path steps within TTC lookahead window
                const clash = this._checkPathClash(b1, b2, currentTick);
                if (clash) {
                    conflicts.push(clash);
                    this.activeConflicts.push(clash);
                }
            }
        }

        return conflicts;
    }

    _checkPathClash(b1, b2, currentTick) {
        const lookahead = CONFIG.ALGO.TTC_LOOKAHEAD_STEPS;
        const p1 = b1.path || [];
        const p2 = b2.path || [];

        const idx1 = b1.pathIndex;
        const idx2 = b2.pathIndex;

        for (let step = 0; step < lookahead; step++) {
            const step1 = (idx1 + step < p1.length) ? p1[idx1 + step] : { col: b1.col, row: b1.row };
            const step2 = (idx2 + step < p2.length) ? p2[idx2 + step] : { col: b2.col, row: b2.row };

            // 1. Vertex Clash (both target same node at step)
            if (step1.col === step2.col && step1.row === step2.row) {
                // Ignore if both are stationary at their home bases
                if (b1.state === 'IDLE' && b2.state === 'IDLE' && (b1.col !== b2.col || b1.row !== b2.row)) {
                    continue;
                }
                return {
                    type: 'VERTEX_CONFLICT',
                    bot1: b1,
                    bot2: b2,
                    col: step1.col,
                    row: step1.row,
                    ttcSteps: step + 1,
                    desc: `Vertex collision predicted at (${step1.col}, ${step1.row}) in ${step + 1} steps`
                };
            }

            // 2. Head-On Swap Clash
            if (step > 0) {
                const prev1 = (idx1 + step - 1 < p1.length) ? p1[idx1 + step - 1] : { col: b1.col, row: b1.row };
                const prev2 = (idx2 + step - 1 < p2.length) ? p2[idx2 + step - 1] : { col: b2.col, row: b2.row };

                if (prev1.col === step2.col && prev1.row === step2.row &&
                    step1.col === prev2.col && step1.row === prev2.row) {
                    return {
                        type: 'HEAD_ON_SWAP',
                        bot1: b1,
                        bot2: b2,
                        col: step1.col,
                        row: step1.row,
                        ttcSteps: step,
                        desc: `Head-on swap detected between (${prev1.col}, ${prev1.row}) and (${step1.col}, ${step1.row})`
                    };
                }
            }
        }

        return null;
    }

    /* ============================================================
     *  Algorithm 6: Priority-Based Conflict Resolution
     * ============================================================ */
    resolveConflicts(conflicts, astarSolver) {
        for (const conflict of conflicts) {
            const { bot1, bot2, col, row, type } = conflict;

            // Update priority values
            const p1 = bot1.updatePriority();
            const p2 = bot2.updatePriority();

            let winner, yielder;
            if (p1 >= p2) {
                winner = bot1;
                yielder = bot2;
            } else {
                winner = bot2;
                yielder = bot1;
            }

            this.logEvent(
                'ARBITRATION',
                `${winner.name} (P:${winner.priority.toFixed(1)}) won right-of-way over ${yielder.name} (P:${yielder.priority.toFixed(1)}) at (${col},${row}) [${type}]`,
                winner.id
            );

            // Instruct yielder to pause or reroute
            if (conflict.ttcSteps === 1) {
                // Immediate clash: yielder must pause or wait
                yielder.state = 'WAITING';
                yielder.waitingTicks++;

                // Record in wait-for graph (Algorithm 8)
                this._addWaitForEdge(yielder.id, winner.id);
            } else {
                // Lookahead clash: attempt dynamic reroute for yielder (Algorithm 9)
                if (astarSolver && yielder.path && yielder.path.length > 0) {
                    const goal = yielder.path[yielder.path.length - 1];
                    const detour = astarSolver.findPath(
                        yielder.col,
                        yielder.row,
                        goal.col,
                        goal.row,
                        0,
                        this.reservationTable,
                        yielder.id,
                        40
                    );
                    if (detour && detour.length > 1) {
                        yielder.setTrajectory(detour);
                        this.reservationTable.reservePath(yielder.id, detour);
                        this.logEvent('REROUTE', `${yielder.name} recalculated detour around ${winner.name}`, yielder.id);
                    } else {
                        yielder.state = 'WAITING';
                    }
                }
            }
        }
    }

    /* ============================================================
     *  Algorithm 7: Deadlock Prevention (Intersection Reservation Locking)
     * ============================================================ */
    manageIntersectionLocks(bots, currentTick) {
        // Clean expired locks
        for (const [key, lock] of this.intersectionLocks.entries()) {
            if (currentTick >= lock.expiresTick) {
                this.intersectionLocks.delete(key);
            }
        }

        // AMRs approaching an intersection must request lock
        for (const bot of bots) {
            if (bot.state !== 'MOVING' || !bot.path) continue;

            const nextStep = (bot.pathIndex < bot.path.length) ? bot.path[bot.pathIndex] : null;
            if (!nextStep) continue;

            if (this.grid.isIntersection(nextStep.col, nextStep.row)) {
                const key = `${nextStep.col},${nextStep.row}`;
                const existingLock = this.intersectionLocks.get(key);

                if (existingLock && existingLock.botId !== bot.id) {
                    // Intersection is currently occupied or locked by another AMR
                    bot.state = 'WAITING';
                    this._addWaitForEdge(bot.id, existingLock.botId);
                    this.logEvent('DEADLOCK', `${bot.name} waiting for intersection (${nextStep.col},${nextStep.row}) locked by ${existingLock.botId}`, bot.id);
                } else {
                    // Acquire lock
                    this.intersectionLocks.set(key, {
                        botId: bot.id,
                        acquiredTick: currentTick,
                        expiresTick: currentTick + CONFIG.ALGO.INTERSECTION_LOCK_STEPS
                    });
                }
            }
        }
    }

    /* ============================================================
     *  Algorithm 8: Deadlock Recovery (Wait-For Graph Cycle Detection)
     * ============================================================ */
    _addWaitForEdge(fromBotId, toBotId) {
        if (!this.waitForGraph.has(fromBotId)) {
            this.waitForGraph.set(fromBotId, new Set());
        }
        this.waitForGraph.get(fromBotId).add(toBotId);
    }

    clearWaitForGraph() {
        this.waitForGraph.clear();
    }

    checkAndResolveDeadlocks(bots, astarSolver) {
        const cycle = this._detectCycleInWFG();
        if (cycle && cycle.length > 0) {
            this.logEvent('DEADLOCK', `DEADLOCK CYCLE DETECTED: [${cycle.join(' -> ')}]`);

            // Find lowest priority bot in the cycle to yield or backoff
            const cycleBots = cycle.map(id => bots.find(b => b.id === id)).filter(Boolean);
            cycleBots.sort((a, b) => a.priority - b.priority);

            const victim = cycleBots[0];
            if (victim) {
                this.logEvent('DEADLOCK', `Resolving cycle: ${victim.name} forced to yield backoff & reroute`, victim.id);
                victim.deadlockRecoveryActive = true;
                victim.state = 'WAITING';
                victim.blockedTicks = 0;

                // Attempt evasive sidestep to free the choke point
                const neighbors = this.grid.getRawOrthogonalNeighbors(victim.col, victim.row);
                // Filter neighbor not occupied by any bot
                const freeNeighbor = neighbors.find(n => !bots.some(b => b.col === n.col && b.row === n.row));

                if (freeNeighbor) {
                    const sidestepPath = [
                        { col: victim.col, row: victim.row, t: 0, dir: null, isWait: false },
                        { col: freeNeighbor.col, row: freeNeighbor.row, t: 1, dir: freeNeighbor.dir, isWait: false }
                    ];
                    victim.setTrajectory(sidestepPath);
                    this.logEvent('REROUTE', `${victim.name} executed evasive sidestep to (${freeNeighbor.col},${freeNeighbor.row})`, victim.id);
                }
            }
            this.clearWaitForGraph();
        }
    }

    _detectCycleInWFG() {
        const visited = new Set();
        const recStack = new Set();
        const cyclePath = [];

        const dfs = (node) => {
            visited.add(node);
            recStack.add(node);
            cyclePath.push(node);

            const neighbors = this.waitForGraph.get(node) || [];
            for (const neighbor of neighbors) {
                if (!visited.has(neighbor)) {
                    if (dfs(neighbor)) return true;
                } else if (recStack.has(neighbor)) {
                    cyclePath.push(neighbor);
                    return true;
                }
            }

            recStack.delete(node);
            cyclePath.pop();
            return false;
        };

        for (const node of this.waitForGraph.keys()) {
            if (!visited.has(node)) {
                if (dfs(node)) return cyclePath;
            }
        }
        return null;
    }
}
